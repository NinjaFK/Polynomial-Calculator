#include "polynomial.h"
#include <iostream>
#include <cstdlib>
#include <cmath>

polynomial::polynomial()
{
	
	
polynomial::polynomial(const polynomial& poly)
{
	
}

polynomial::polynomial(int * p, int degree)
{
	
}
	
polynomial::polynomial(int s)
{
	
}

polynomial::~polynomial()
{
	
}

polynomial polynomial::operator*(const polynomial& rhs) const
{
	
}

polynomial polynomial::operator*(int rhs) const
{
	
}
	
polynomial polynomial::operator+(const polynomial& rhs) const
{
	
}

polynomial polynomial::operator+(int rhs) const
{
	
}

const polynomial& polynomial::operator=(const polynomial& rhs)
{
	
}

const polynomial& polynomial::operator=(int rhs)
{
	
}

polynomial polynomial::operator-() const
{
	
}

polynomial polynomial::operator-(const polynomial& rhs) const
{
	
}
	
polynomial polynomial::operator-(int rhs) const
{
	
}

std::ostream& operator<<(std::ostream& out, const polynomial& rhs)
{
	
}

polynomial operator+(int lhs, const polynomial& rhs)
{
	
}

polynomial operator*(int lhs, const polynomial& rhs)
{
	
}

polynomial operator-(int lhs, const polynomial& rhs)
{
	
}